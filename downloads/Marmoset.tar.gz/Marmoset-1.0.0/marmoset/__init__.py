"""
@author: Ford Peprah
@authors: Ford Peprah
@copyright: Ford Peprah, 2012, 2013
@license: GNU General Public License
@version: 1.0.0
"""
from core.marmosetbrowser import Marmoset, NotTestedYet, BrowserException, NoMatchingQueryException
from core.marmosetsession import MarmosetSession
import utils


__author__="Ford Peprah"
__prog__="marmoset"
__version__="1.0.0"
__copyright__="(C) Ford Peprah, 2012-2014"
__description__=""
