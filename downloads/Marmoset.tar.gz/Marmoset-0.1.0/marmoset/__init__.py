"""
@author: Ford Peprah
@authors: Ford Peprah
@copyright: Ford Peprah, 2012, 2013
@license: GNU General Public License
@version: 0.1.0
"""
from core.marmoset_browser import Marmoset
from utils import *


__author__="Ford Peprah"
__prog__="marmoset"
__version__="0.1.0"
__copyright__="(C) Ford Peprah, 2012-2013"
__description__=""
